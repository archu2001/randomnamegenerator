const supervillains = require('supervillains');

console.log("Random Name Generated is" ,supervillains.random());
